import { redirect } from "next/navigation";

export default function PracticePage() {
  redirect("/practice/subjects");
}
