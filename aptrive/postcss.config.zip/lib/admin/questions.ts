import { createClient } from "@/lib/supabase/server";
import type { Database, QuestionStatus, Difficulty, BloomLevel, QuestionType } from "@/lib/database.types";

// The hand-authored Database type lacks Supabase's Relationships
// metadata, which causes .insert() / .update() argument types to
// resolve to `never`.  The workaround is to cast the query-builder
// itself — `supabase.from(...)` — so that every chained
// call is untyped.  Results are still cast back to the correct row
// types via `as unknown as T`.
type QuestionRow = Database["public"]["Tables"]["questions"]["Row"];
type OptionRow = Database["public"]["Tables"]["question_options"]["Row"];
type QuestionVersionRow = Database["public"]["Tables"]["question_versions"]["Row"];

export type QuestionWithOptions = Omit<QuestionRow, "status" | "difficulty"> & {
  status: QuestionStatus;
  difficulty: Difficulty;
  options: OptionRow[];
  subjects: { name: string } | null;
  practice_sets: { title: string } | null;
};

export type QuestionListFilters = {
  search?: string;
  status?: QuestionStatus | "all";
  subjectId?: string;
  practiceSetId?: string;
  difficulty?: Difficulty | "all";
  page?: number;
  pageSize?: number;
};

const DEFAULT_PAGE_SIZE = 25;

export type QuestionListRow = Omit<
  Pick<
    QuestionRow,
    | "id"
    | "prompt"
    | "difficulty"
    | "topic"
    | "chapter"
    | "status"
    | "tags"
    | "ai_generated"
    | "human_reviewed"
    | "current_version"
    | "updated_at"
  >,
  "status" | "difficulty"
> & {
  status: QuestionStatus;
  difficulty: Difficulty;
  subjects: { name: string } | null;
  practice_sets: { title: string } | null;
};

/**
 * Searchable/filterable question list for the admin table. Uses
 * offset pagination — fine at the row counts this table will see for
 * a while; switch to keyset (createdAt/id cursor) if it ever needs to
 * comfortably page past the tens of thousands of rows mark.
 */
export async function listQuestionsForAdmin(filters: QuestionListFilters) {
  const supabase = await createClient();
  const page = Math.max(1, filters.page ?? 1);
  const pageSize = filters.pageSize ?? DEFAULT_PAGE_SIZE;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from("questions")
    .select(
      "id, prompt, difficulty, topic, chapter, status, tags, ai_generated, human_reviewed, current_version, updated_at, subjects(name), practice_sets(title)",
      { count: "exact" }
    )
    .order("updated_at", { ascending: false })
    .range(from, to);

  if (filters.search) {
    query = query.ilike("prompt", `%${filters.search}%`);
  }
  if (filters.status && filters.status !== "all") {
    query = query.eq("status", filters.status);
  }
  if (filters.subjectId) {
    query = query.eq("subject_id", filters.subjectId);
  }
  if (filters.practiceSetId) {
    query = query.eq("practice_set_id", filters.practiceSetId);
  }
  if (filters.difficulty && filters.difficulty !== "all") {
    query = query.eq("difficulty", filters.difficulty);
  }

  const { data, error, count } = await query;
  if (error) throw error;

  return {
    // See the comment on ImportBatchRow in lib/admin/import.ts — the
    // hand-authored Database type has no Relationships metadata, so
    // this embedded select needs an explicit cast rather than relying
    // on inference (which otherwise resolves the joined fields to
    // `never` and breaks every consumer of `.rows`).
    rows: (data ?? []) as unknown as QuestionListRow[],
    total: count ?? 0,
    page,
    pageSize,
    totalPages: Math.max(1, Math.ceil((count ?? 0) / pageSize)),
  };
}

export async function getQuestionForAdmin(id: string): Promise<QuestionWithOptions | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("questions")
    .select("*, options:question_options(*), subjects(name), practice_sets(title)")
    .eq("id", id)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;

  return {
    ...(data as unknown as QuestionRow),
    options: ((data as unknown as { options: OptionRow[] }).options ?? []).sort(
      (a, b) => a.position - b.position
    ),
    subjects: (data as unknown as { subjects: { name: string } | null }).subjects,
    practice_sets: (data as unknown as { practice_sets: { title: string } | null }).practice_sets,
  } as unknown as QuestionWithOptions;
}

export async function listQuestionVersions(questionId: string): Promise<QuestionVersionRow[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("question_versions")
    .select("*")
    .eq("question_id", questionId)
    .order("version_number", { ascending: false });

  if (error) throw error;
  return (data ?? []) as unknown as QuestionVersionRow[];
}

export type QuestionOptionInput = {
  content: string;
  is_correct: boolean;
};

export type QuestionFormInput = {
  practice_set_id: string;
  subject_id: string;
  prompt: string;
  explanation: string | null;
  difficulty: Difficulty;
  topic: string;
  chapter: string | null;
  time_estimate_seconds: number;
  status: QuestionStatus;
  source: string | null;
  source_year: number | null;
  tags: string[];
  ai_generated: boolean;
  options: QuestionOptionInput[];
  // Phase 0/1 fields:
  university_id: string | null;
  test_id: string | null;
  chapter_id: string;
  topic_id: string;
  subtopic_id: string | null;
  difficulty_level_id: string;
  bloom_level: BloomLevel;
  question_type: QuestionType;
  numeric_answer_value: number | null;
  numeric_answer_tolerance: number | null;
};

/**
 * Creates a question and its options in one call. Not wrapped in an
 * explicit SQL transaction (the anon client can't open one) — if the
 * options insert fails after the question insert succeeds, the
 * question is deleted again so we don't leave an optionless row
 * behind. Acceptable for admin-authored content at this volume; the
 * CSV importer (lib/admin/import.ts) does the same pattern per row.
 */
export async function createQuestion(input: QuestionFormInput, createdBy: string) {
  const supabase = await createClient();

    const { data: question, error: questionError } = await supabase.from("questions")
    .insert({
      practice_set_id: input.practice_set_id,
      subject_id: input.subject_id,
      prompt: input.prompt,
      explanation: input.explanation,
      difficulty: input.difficulty,
      topic: input.topic,
      chapter: input.chapter,
      time_estimate_seconds: input.time_estimate_seconds,
      status: input.status,
      source: input.source,
      source_year: input.source_year,
      tags: input.tags,
      ai_generated: input.ai_generated,
      created_by: createdBy,
      // Phase 0/1 columns
      university_id: input.university_id,
      test_id: input.test_id,
      chapter_id: input.chapter_id,
      topic_id: input.topic_id,
      subtopic_id: input.subtopic_id,
      difficulty_level_id: input.difficulty_level_id,
      bloom_level: input.bloom_level,
      question_type: input.question_type,
      numeric_answer_value: input.numeric_answer_value,
      numeric_answer_tolerance: input.numeric_answer_tolerance,
    })
    .select("id")
    .single();

  if (questionError) throw questionError;
  const questionId = (question as unknown as { id: string }).id;

    const { error: optionsError } = await supabase.from("question_options").insert(
    input.options.map((option, index) => ({
      question_id: questionId,
      content: option.content,
      is_correct: option.is_correct,
      position: index,
    }))
  );

  if (optionsError) {
    await supabase.from("questions").delete().eq("id", questionId);
    throw optionsError;
  }

  return questionId;
}

/**
 * Updates a question's fields and fully replaces its options
 * (delete + re-insert, simplest correct way to handle option
 * add/remove/reorder from a form without diffing). The
 * `snapshot_question_version` trigger (0005 migration) captures the
 * pre-update state automatically when prompt/explanation/status/
 * difficulty change.
 *
 * FIXED 2026-07-29: this delete-then-reinsert wasn't atomic and had no
 * compensating action if the insert failed after the delete succeeded
 * — unlike `createQuestion` above, which correctly deletes the
 * orphaned question if its options insert fails. A previously-working,
 * possibly-published question could end up with zero answer choices
 * and no automatic recovery. Fix: snapshot the existing options before
 * deleting them, and if the re-insert fails, attempt to restore that
 * snapshot. If the restore itself also fails (e.g. the DB connection
 * dropped mid-operation), force the question to `draft` as a
 * last-resort safety net so a broken, optionless question can never be
 * served to students — then rethrow so the caller knows something went
 * wrong either way.
 */
export async function updateQuestion(
  id: string,
  input: QuestionFormInput,
  reviewedBy: string
) {
  const supabase = await createClient();

    const { error: questionError } = await supabase.from("questions")
    .update({
      practice_set_id: input.practice_set_id,
      subject_id: input.subject_id,
      prompt: input.prompt,
      explanation: input.explanation,
      difficulty: input.difficulty,
      topic: input.topic,
      chapter: input.chapter,
      time_estimate_seconds: input.time_estimate_seconds,
      status: input.status,
      source: input.source,
      source_year: input.source_year,
      tags: input.tags,
      ai_generated: input.ai_generated,
      reviewed_by: reviewedBy,
      // Phase 0/1 columns
      university_id: input.university_id,
      test_id: input.test_id,
      chapter_id: input.chapter_id,
      topic_id: input.topic_id,
      subtopic_id: input.subtopic_id,
      difficulty_level_id: input.difficulty_level_id,
      bloom_level: input.bloom_level,
      question_type: input.question_type,
      numeric_answer_value: input.numeric_answer_value,
      numeric_answer_tolerance: input.numeric_answer_tolerance,
    })
    .eq("id", id);

  if (questionError) throw questionError;

  // Snapshot the current options before touching them, so we can
  // restore them if the re-insert below fails.
  const { data: existingOptions, error: snapshotError } = await supabase
    .from("question_options")
    .select("content, is_correct, position")
    .eq("question_id", id);
  if (snapshotError) throw snapshotError;
  const optionsSnapshot = (existingOptions ?? []) as unknown as Pick<
    OptionRow,
    "content" | "is_correct" | "position"
  >[];

  const { error: deleteError } = await supabase
    .from("question_options")
    .delete()
    .eq("question_id", id);
  if (deleteError) throw deleteError;

    const { error: insertError } = await supabase.from("question_options").insert(
    input.options.map((option, index) => ({
      question_id: id,
      content: option.content,
      is_correct: option.is_correct,
      position: index,
    }))
  );

  if (insertError) {
        const { error: restoreError } = await supabase.from("question_options").insert(
      optionsSnapshot.map((option) => ({
        question_id: id,
        content: option.content,
        is_correct: option.is_correct,
        position: option.position,
      }))
    );

    if (restoreError) {
      // Restore also failed — the question would otherwise be left
      // with zero options. Force it back to draft so it can't be
      // served to students in a broken state, regardless of whatever
      // status the form submitted.
            await supabase.from("questions")
        .update({ status: "draft" })
        .eq("id", id);
      throw new Error(
        `Failed to save new options (${insertError.message}), and restoring the previous options also failed (${restoreError.message}). The question has been forced back to draft status to prevent it being served with no answer choices.`
      );
    }

    throw new Error(
      `Failed to save new options: ${insertError.message}. The question's previous options have been restored, so no data was lost.`
    );
  }
}

export async function setQuestionStatus(id: string, status: QuestionStatus) {
  const supabase = await createClient();
    const { error } = await supabase.from("questions").update({ status }).eq("id", id);
  if (error) throw error;
}

export async function duplicateQuestion(id: string, createdBy: string) {
  const supabase = await createClient();
  const original = await getQuestionForAdmin(id);
  if (!original) throw new Error("Question not found");
  if (!original.difficulty_level_id) {
    throw new Error("Cannot duplicate this question: it has no difficulty level assigned.");
  }
  if (!original.bloom_level) {
    throw new Error("Cannot duplicate this question: it has no Bloom's level assigned.");
  }

  const newId = await createQuestion(
    {
      practice_set_id: original.practice_set_id,
      subject_id: original.subject_id,
      prompt: `${original.prompt} (copy)`,
      explanation: original.explanation,
      difficulty: original.difficulty,
      topic: original.topic,
      chapter: original.chapter,
      time_estimate_seconds: original.time_estimate_seconds,
      status: "draft",
      source: original.source,
      source_year: original.source_year,
      tags: original.tags,
      ai_generated: original.ai_generated,
      options: original.options.map((o) => ({ content: o.content, is_correct: o.is_correct })),
      // Phase 0/1 columns
      university_id: original.university_id,
      test_id: original.test_id,
      chapter_id: original.chapter_id,
      topic_id: original.topic_id,
      subtopic_id: original.subtopic_id,
      difficulty_level_id: original.difficulty_level_id,
      bloom_level: original.bloom_level,
      question_type: original.question_type,
      numeric_answer_value: original.numeric_answer_value,
      numeric_answer_tolerance: original.numeric_answer_tolerance,
    },
    createdBy
  );

    const { error } = await supabase.from("questions")
    .update({ duplicated_from_id: id })
    .eq("id", newId);
  if (error) throw error;

  return newId;
}
